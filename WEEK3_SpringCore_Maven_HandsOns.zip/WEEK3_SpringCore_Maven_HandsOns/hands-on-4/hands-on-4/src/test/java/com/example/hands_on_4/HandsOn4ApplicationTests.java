package com.example.hands_on_4;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HandsOn4ApplicationTests {

	@Test
	void contextLoads() {
	}

}
