package com.example.hands_on_4;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class Employee {

    @Id
    private int id;
    private String name;

    // 🔹 Default constructor (required by JPA)
    public Employee() {}

    // 🔹 Parameterized constructor (your current error needs this)
    public Employee(int id, String name) {
        this.id = id;
        this.name = name;
    }

    // 🔹 Getters and setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    // Optional: For logging/debugging
    @Override
    public String toString() {
        return "Employee [id=" + id + ", name=" + name + "]";
    }
}
