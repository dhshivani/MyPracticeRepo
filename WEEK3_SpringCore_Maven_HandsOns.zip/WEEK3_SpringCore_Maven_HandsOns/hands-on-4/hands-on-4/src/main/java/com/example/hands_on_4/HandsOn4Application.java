package com.example.hands_on_4;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HandsOn4Application implements CommandLineRunner {

    @Autowired
    private EmployeeService employeeService;

    public static void main(String[] args) {
        SpringApplication.run(HandsOn4Application.class, args);
    }

    @Override
    public void run(String... args) throws Exception {
        Employee emp = new Employee(1, "Dharshini");
        employeeService.addEmployee(emp);
        System.out.println("Employee added successfully.");
    }
}
