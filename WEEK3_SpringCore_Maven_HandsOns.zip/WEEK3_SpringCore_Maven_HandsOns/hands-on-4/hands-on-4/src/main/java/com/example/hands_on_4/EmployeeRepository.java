package com.example.hands_on_4;

import org.springframework.data.jpa.repository.JpaRepository;

public interface EmployeeRepository extends JpaRepository<Employee, Integer> {
    // No need to write any method, JpaRepository provides basic CRUD methods
}
