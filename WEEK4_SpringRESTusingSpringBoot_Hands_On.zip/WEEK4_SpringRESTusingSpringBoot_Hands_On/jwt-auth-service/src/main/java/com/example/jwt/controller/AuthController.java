package com.example.jwt.controller;

import com.example.jwt.util.JwtUtil;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

@RestController
public class AuthController {

    /**
     * GET /authenticate
     * Credentials come via HTTP Basic header, decoded automatically by Spring Security.
     * If authentication succeeds, Spring inserts an Authentication object.
     */
    @GetMapping("/authenticate")
    public ResponseEntity<Map<String, String>> authenticate(Authentication auth) {
        // "auth" will be non‑null only if credentials were correct
        String username = auth.getName();
        String token    = JwtUtil.generateToken(username);
        return ResponseEntity.ok(Map.of("token", token));
    }
}
